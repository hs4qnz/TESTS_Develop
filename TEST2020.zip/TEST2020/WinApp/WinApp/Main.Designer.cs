﻿namespace WinApp
{
    partial class fmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSort = new System.Windows.Forms.Button();
            this.txtInput = new System.Windows.Forms.TextBox();
            this.btnReverse = new System.Windows.Forms.Button();
            this.btnOrderNum = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnSort
            // 
            this.btnSort.Location = new System.Drawing.Point(29, 98);
            this.btnSort.Name = "btnSort";
            this.btnSort.Size = new System.Drawing.Size(183, 27);
            this.btnSort.TabIndex = 0;
            this.btnSort.Text = "Sorting";
            this.btnSort.UseVisualStyleBackColor = true;
            this.btnSort.Click += new System.EventHandler(this.btnSort_Click);
            // 
            // txtInput
            // 
            this.txtInput.Location = new System.Drawing.Point(12, 12);
            this.txtInput.Multiline = true;
            this.txtInput.Name = "txtInput";
            this.txtInput.Size = new System.Drawing.Size(641, 60);
            this.txtInput.TabIndex = 1;
            // 
            // btnReverse
            // 
            this.btnReverse.Location = new System.Drawing.Point(29, 145);
            this.btnReverse.Name = "btnReverse";
            this.btnReverse.Size = new System.Drawing.Size(183, 27);
            this.btnReverse.TabIndex = 2;
            this.btnReverse.Text = "Reverse";
            this.btnReverse.UseVisualStyleBackColor = true;
            this.btnReverse.Click += new System.EventHandler(this.btnReverse_Click);
            // 
            // btnOrderNum
            // 
            this.btnOrderNum.Location = new System.Drawing.Point(29, 192);
            this.btnOrderNum.Name = "btnOrderNum";
            this.btnOrderNum.Size = new System.Drawing.Size(183, 23);
            this.btnOrderNum.TabIndex = 3;
            this.btnOrderNum.Text = "OrderNum";
            this.btnOrderNum.UseVisualStyleBackColor = true;
            this.btnOrderNum.Click += new System.EventHandler(this.btnOrderNum_Click);
            // 
            // fmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(686, 295);
            this.Controls.Add(this.btnOrderNum);
            this.Controls.Add(this.btnReverse);
            this.Controls.Add(this.txtInput);
            this.Controls.Add(this.btnSort);
            this.Name = "fmMain";
            this.Text = "Main";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSort;
        private System.Windows.Forms.TextBox txtInput;
        private System.Windows.Forms.Button btnReverse;
        private System.Windows.Forms.Button btnOrderNum;
    }
}

