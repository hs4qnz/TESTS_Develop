﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinApp
{
    public partial class fmMain : Form
    {

        string RunOrderNum = String.Empty;

        public fmMain()
        {
            InitializeComponent();
        }

        private void btnSort_Click(object sender, EventArgs e)
        {


            string[] Sorts = txtInput.Text.Split(',');

            string orderNum = null;
            string MapText = null;
            string out1 = null;
            string MapText2 = null;
            string out2 = null;
            string ShowSort = "";


            foreach (string Sort in Sorts)
            {


                if (Sort.StartsWith("A"))
                {
                    //Array.Sort(Sorts);
                    orderNum = (String.Join(" ", Sort));
                    MapText = orderNum += " ";

                }

                else if (Sort.StartsWith("E"))
                {
                    //Array.Sort(Sorts);
                    orderNum = (String.Join(" ", Sort));
                    MapText = out1 += orderNum += " ";
                }

                else if (Sort.StartsWith("I"))
                {
                    //Array.Sort(Sorts);
                    orderNum = (String.Join(" ", Sort));
                    MapText = out1 += orderNum += " ";
                }


                else if (Sort.StartsWith("O"))
                {
                    //Array.Sort(Sorts);
                    orderNum = (String.Join(" ", Sort));
                    MapText = out1 += orderNum += " ";
                }

                else if (Sort.StartsWith("U"))
                {
                    //Array.Sort(Sorts);
                    orderNum = (String.Join(" ", Sort));
                    MapText = out1 += orderNum += " ";
                }


                else
                {
                    //Array.Sort(Sorts);

                    orderNum = (String.Join(" ", Sort));
                    MapText2 = out2 += orderNum += " ";
                }

                out1 = MapText;
                out2 = MapText2;


            }

            ShowSort = out1 + out2;
            MessageBox.Show(ShowSort);

        }

        public string ReverseMessage(String input)
        {


            string output = string.Empty;
            string[] splitStrings = input.Split(' ');
            for (int i = splitStrings.Length - 1; i > -1; i--)
            {
                output = output + splitStrings[i] + " ";
            }


            return output;

        }


        private void btnReverse_Click(object sender, EventArgs e)
        {


            String Reverse = ReverseMessage(txtInput.Text.Replace(",", "").Replace(".", ""));
            MessageBox.Show("Answer: " + Reverse);
        }


        public static void OrderNumber(int[] intArray)
        {

            int inum = 0;

            for (int i = 0; i <= intArray.Length - 1; i++)
            {
                for (int j = i + 1; j < intArray.Length; j++)
                {
                    if (intArray[i] > intArray[j])
                    {
                        inum = intArray[i];
                        intArray[i] = intArray[j];
                        intArray[j] = inum;
                    }
                }
            }

            foreach (var inums in intArray)
            {

                string orderNum = (String.Join(" ", inums));

            }

        }

        private void btnOrderNum_Click(object sender, EventArgs e)
        {



            string orderNum = null;
            string MapText = null;
            string out1 = null;
            string MapText2 = null;
            string out2 = null;
            int[] intNumbers;


            intNumbers = txtInput.Text.Split(',').Select(int.Parse).ToArray();

            OrderNumber(intNumbers);
            RunOrderNum = (String.Join(", ", intNumbers));

          

            if (RunOrderNum == String.Empty)

            {

                intNumbers = txtInput.Text.Split(',').Select(int.Parse).ToArray();

            }

            else
            {

                intNumbers = RunOrderNum.Split(',').Select(int.Parse).ToArray();

            }

            int j;

            for (int i = 0; i < intNumbers.Length; i++)
            {
                if (intNumbers[i] == 1) 
                {
                    orderNum = (String.Join(" ", +intNumbers[i]));
                    MapText = out1 += orderNum += " ";
                }

                for (j = 2; j < intNumbers[i]; j++)
                    if ((intNumbers[i] % j == 0))
                    {


                        orderNum = (String.Join(" ", +intNumbers[i]));
                        MapText = out1 += orderNum += " ";


                        break;
                    }
                if (j == intNumbers[i])
                {

                    orderNum = (String.Join(" ", +intNumbers[i]));
                    MapText2 = out2 += orderNum += " ";


                }


            }

            out1 = MapText;
            out2 = MapText2;



            MessageBox.Show("Numbers: " + (String.Join(", ", intNumbers)) + Environment.NewLine + "Answer Primer: " + out2 + Environment.NewLine + "Answer Number: " + out1);


        }



    }


}